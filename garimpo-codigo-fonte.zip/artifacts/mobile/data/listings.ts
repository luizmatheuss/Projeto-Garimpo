import type { ImageSourcePropType } from 'react-native';

export const categories = [
  'Moda',
  'Casa',
  'Acessórios',
  'Eletrônicos',
] as const;

export type Category = (typeof categories)[number];
export type Condition = 'Novo' | 'Seminovo' | 'Usado';
export type ListingImageKey = 'jacket' | 'lamp' | 'headphones';

export interface Listing {
  id: string;
  title: string;
  price: number;
  category: Category;
  condition: Condition;
  city: string;
  description: string;
  whatsapp?: string;
  photoUri?: string;
  imageKey?: ListingImageKey;
  isDemo?: boolean;
  createdAt: string;
}

export const sampleListings: Listing[] = [
  {
    id: 'demo-jacket',
    title: 'Jaqueta jeans vintage',
    price: 129,
    category: 'Moda',
    condition: 'Seminovo',
    city: 'São Paulo, SP',
    description:
      'Jaqueta confortável, bem conservada e com aquele jeans que combina com tudo.',
    imageKey: 'jacket',
    isDemo: true,
    createdAt: '2026-11-14T12:00:00.000Z',
  },
  {
    id: 'demo-lamp',
    title: 'Luminária de madeira',
    price: 185,
    category: 'Casa',
    condition: 'Usado',
    city: 'Campinas, SP',
    description:
      'Luminária de mesa em ótimo estado. Uma peça charmosa para deixar o ambiente mais aconchegante.',
    imageKey: 'lamp',
    isDemo: true,
    createdAt: '2026-11-13T12:00:00.000Z',
  },
  {
    id: 'demo-headphones',
    title: 'Fone Bluetooth',
    price: 240,
    category: 'Eletrônicos',
    condition: 'Seminovo',
    city: 'Santos, SP',
    description:
      'Fone sem fio funcionando perfeitamente, com marcas leves de uso.',
    imageKey: 'headphones',
    isDemo: true,
    createdAt: '2026-11-12T12:00:00.000Z',
  },
];

const listingImages: Record<ListingImageKey, ImageSourcePropType> = {
  jacket: require('../assets/images/listing-jacket.jpg'),
  lamp: require('../assets/images/listing-lamp.jpg'),
  headphones: require('../assets/images/listing-headphones.jpg'),
};

export function getListingImageSource(
  listing: Listing,
): ImageSourcePropType | undefined {
  if (listing.photoUri) return { uri: listing.photoUri };
  if (listing.imageKey) return listingImages[listing.imageKey];
  return undefined;
}

export function formatPrice(price: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    maximumFractionDigits: 2,
  }).format(price);
}
