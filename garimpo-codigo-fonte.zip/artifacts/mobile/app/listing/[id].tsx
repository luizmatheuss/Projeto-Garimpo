import { Feather } from '@expo/vector-icons';
import { useLocalSearchParams, router } from 'expo-router';
import { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Image,
  Linking,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useMarketplace } from '@/contexts/MarketplaceContext';
import {
  formatPrice,
  getListingImageSource,
} from '@/data/listings';
import { useColors } from '@/hooks/useColors';

export default function ListingDetailScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { listings, favorites, isReady, toggleFavorite } = useMarketplace();
  const [isContacting, setIsContacting] = useState(false);
  const listing = listings.find((item) => item.id === id);
  const imageSource = listing ? getListingImageSource(listing) : undefined;
  const topInset =
    Platform.OS === 'web' ? Math.max(insets.top, 67) + 8 : insets.top + 10;

  const handleFavorite = () => {
    if (!listing) return;
    void toggleFavorite(listing.id).catch(() =>
      Alert.alert(
        'Não foi possível atualizar',
        'Tente favoritar este anúncio novamente.',
      ),
    );
  };

  const contactSeller = async () => {
    if (!listing) return;
    if (!listing.whatsapp) {
      Alert.alert(
        'Contato de demonstração',
        'Este anúncio de exemplo não tem um número de vendedor. Anúncios publicados por você incluem o WhatsApp informado.',
      );
      return;
    }
    const digits = listing.whatsapp.replace(/\D/g, '');
    const phone = digits.startsWith('55') ? digits : `55${digits}`;
    const message = encodeURIComponent(
      `Olá! Tenho interesse no anúncio "${listing.title}". Ainda está disponível?`,
    );
    setIsContacting(true);
    try {
      await Linking.openURL(`https://wa.me/${phone}?text=${message}`);
    } catch {
      Alert.alert(
        'Não foi possível abrir o WhatsApp',
        'Confira se o WhatsApp está disponível no seu aparelho.',
      );
    } finally {
      setIsContacting(false);
    }
  };

  if (!isReady) {
    return (
      <View
        style={[
          styles.loadingScreen,
          { backgroundColor: colors.background, paddingTop: topInset },
        ]}
      >
        <ActivityIndicator color={colors.tint} />
      </View>
    );
  }

  if (!listing) {
    return (
      <View
        style={[
          styles.loadingScreen,
          { backgroundColor: colors.background, paddingTop: topInset },
        ]}
      >
        <Feather name="alert-circle" size={28} color={colors.mutedForeground} />
        <Text style={[styles.missingTitle, { color: colors.foreground }]}>
          Anúncio não encontrado
        </Text>
        <Pressable
          accessibilityRole="button"
          onPress={() => router.replace('/(tabs)')}
          style={[styles.backToExplore, { backgroundColor: colors.primary }]}
        >
          <Text style={[styles.contactText, { color: colors.primaryForeground }]}>
            Voltar aos anúncios
          </Text>
        </Pressable>
      </View>
    );
  }

  const isFavorite = favorites.includes(listing.id);

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <View style={[styles.topBar, { paddingTop: topInset }]}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Voltar"
          onPress={() => router.back()}
          style={[styles.iconButton, { backgroundColor: colors.card }]}
          testID="listing-back"
        >
          <Feather name="arrow-left" size={20} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.topTitle, { color: colors.foreground }]}>
          Detalhes do achado
        </Text>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={
            isFavorite ? 'Remover dos favoritos' : 'Adicionar aos favoritos'
          }
          onPress={handleFavorite}
          style={[styles.iconButton, { backgroundColor: colors.card }]}
          testID="detail-favorite"
        >
          <Feather
            name="heart"
            size={20}
            color={isFavorite ? colors.tint : colors.foreground}
            fill={isFavorite ? colors.tint : 'transparent'}
          />
        </Pressable>
      </View>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {imageSource ? (
          <Image source={imageSource} style={styles.heroImage} resizeMode="cover" />
        ) : (
          <View
            style={[
              styles.imageFallback,
              { backgroundColor: colors.muted },
            ]}
          >
            <Feather name="image" size={42} color={colors.mutedForeground} />
          </View>
        )}
        <View style={styles.details}>
          <View style={styles.metaRow}>
            <View style={[styles.categoryChip, { backgroundColor: colors.accent }]}>
              <Text style={[styles.categoryText, { color: colors.accentForeground }]}>
                {listing.category}
              </Text>
            </View>
            <Text style={[styles.condition, { color: colors.mutedForeground }]}>
              {listing.condition}
            </Text>
          </View>
          {listing.isDemo ? (
            <Text style={[styles.demoNote, { color: colors.mutedForeground }]}>
              Anúncio de exemplo para você conhecer o Garimpo.
            </Text>
          ) : null}
          <Text style={[styles.title, { color: colors.foreground }]}>
            {listing.title}
          </Text>
          <Text style={[styles.price, { color: colors.foreground }]}>
            {formatPrice(listing.price)}
          </Text>
          <View style={styles.cityRow}>
            <Feather name="map-pin" size={16} color={colors.tint} />
            <Text style={[styles.city, { color: colors.mutedForeground }]}>
              {listing.city}
            </Text>
          </View>
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <Text style={[styles.sectionLabel, { color: colors.foreground }]}>
            Sobre o produto
          </Text>
          <Text style={[styles.description, { color: colors.mutedForeground }]}>
            {listing.description}
          </Text>
        </View>
      </ScrollView>
      <View
        style={[
          styles.bottomAction,
          {
            backgroundColor: colors.background,
            borderTopColor: colors.border,
            paddingBottom: Platform.OS === 'web' ? 34 : insets.bottom + 14,
          },
        ]}
      >
        <Pressable
          accessibilityRole="button"
          disabled={isContacting}
          onPress={() => void contactSeller()}
          style={({ pressed }) => [
            styles.contactButton,
            { backgroundColor: colors.primary },
            pressed && styles.pressed,
          ]}
          testID="contact-seller"
        >
          {isContacting ? (
            <ActivityIndicator color={colors.primaryForeground} />
          ) : (
            <>
              <Feather name="message-circle" size={19} color={colors.primaryForeground} />
              <Text style={[styles.contactText, { color: colors.primaryForeground }]}>
                Tenho interesse
              </Text>
              <Feather name="arrow-up-right" size={18} color={colors.primaryForeground} />
            </>
          )}
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },
  loadingScreen: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 14,
    paddingHorizontal: 24,
  },
  missingTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 18,
    textAlign: 'center',
  },
  backToExplore: {
    minHeight: 48,
    borderRadius: 15,
    paddingHorizontal: 17,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 4,
  },
  topBar: {
    minHeight: 60,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 18,
    paddingBottom: 12,
  },
  iconButton: {
    width: 42,
    height: 42,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  topTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 15,
  },
  scrollContent: {
    paddingBottom: 20,
  },
  heroImage: {
    width: '100%',
    height: 320,
  },
  imageFallback: {
    width: '100%',
    height: 280,
    alignItems: 'center',
    justifyContent: 'center',
  },
  details: {
    paddingHorizontal: 22,
    paddingTop: 20,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  categoryChip: {
    borderRadius: 99,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  categoryText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 11,
  },
  condition: {
    fontFamily: 'Inter_500Medium',
    fontSize: 12,
  },
  demoNote: {
    fontFamily: 'Inter_400Regular',
    fontSize: 11,
    marginBottom: 8,
  },
  title: {
    fontFamily: 'Inter_700Bold',
    fontSize: 25,
    lineHeight: 31,
  },
  price: {
    fontFamily: 'Inter_700Bold',
    fontSize: 22,
    marginTop: 7,
  },
  cityRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    marginTop: 12,
  },
  city: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
  },
  divider: {
    height: 1,
    marginVertical: 21,
  },
  sectionLabel: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 15,
    marginBottom: 8,
  },
  description: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    lineHeight: 22,
  },
  bottomAction: {
    borderTopWidth: 1,
    paddingHorizontal: 20,
    paddingTop: 12,
  },
  contactButton: {
    minHeight: 54,
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  contactText: {
    fontFamily: 'Inter_700Bold',
    fontSize: 15,
  },
  pressed: {
    opacity: 0.84,
  },
});
