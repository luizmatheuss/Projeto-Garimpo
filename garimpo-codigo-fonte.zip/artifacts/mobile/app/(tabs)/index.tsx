import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ListingCard } from '@/components/ListingCard';
import { categories } from '@/data/listings';
import { useColors } from '@/hooks/useColors';
import { useMarketplace } from '@/contexts/MarketplaceContext';

const categoryFilters = ['Todos', ...categories] as const;

export default function ExploreScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { listings, favorites, isReady, storageError, toggleFavorite } =
    useMarketplace();
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] =
    useState<(typeof categoryFilters)[number]>('Todos');

  const filteredListings = useMemo(() => {
    const query = search.trim().toLocaleLowerCase('pt-BR');
    return listings.filter((listing) => {
      const matchesCategory =
        selectedCategory === 'Todos' || listing.category === selectedCategory;
      const matchesSearch =
        !query ||
        `${listing.title} ${listing.description} ${listing.city}`
          .toLocaleLowerCase('pt-BR')
          .includes(query);
      return matchesCategory && matchesSearch;
    });
  }, [listings, search, selectedCategory]);

  const openListing = (id: string) => {
    router.push({ pathname: '/listing/[id]', params: { id } });
  };

  const handleFavorite = (id: string) => {
    void toggleFavorite(id).catch(() =>
      Alert.alert(
        'Não foi possível salvar',
        'Tente favoritar este anúncio novamente.',
      ),
    );
  };

  const topInset =
    Platform.OS === 'web' ? Math.max(insets.top, 67) + 10 : insets.top + 14;

  return (
    <KeyboardAvoidingView
      behavior="padding"
      keyboardVerticalOffset={0}
      style={[styles.screen, { backgroundColor: colors.background }]}
    >
      <FlatList
        data={isReady ? filteredListings : []}
        numColumns={2}
        keyExtractor={(item) => item.id}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={[
          styles.listContent,
          { paddingBottom: Platform.OS === 'web' ? 34 : 24 },
          filteredListings.length === 0 && styles.emptyListContent,
        ]}
        columnWrapperStyle={styles.column}
        ListHeaderComponent={
          <View style={{ paddingTop: topInset }}>
            <View style={styles.brandLine}>
              <Text style={[styles.eyebrow, { color: colors.tint }]}>
                GARIMPO
              </Text>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Ver favoritos"
                onPress={() => router.navigate('/(tabs)/favorites')}
                style={[
                  styles.headerAction,
                  { backgroundColor: colors.accent },
                ]}
                testID="open-favorites"
              >
                <Feather name="shopping-bag" size={19} color={colors.accentForeground} />
              </Pressable>
            </View>
            <Text style={[styles.hero, { color: colors.foreground }]}>
              Encontre seu próximo achado.
            </Text>
            <View
              style={[
                styles.searchField,
                { borderColor: colors.border, backgroundColor: colors.input },
              ]}
            >
              <Feather name="search" size={19} color={colors.mutedForeground} />
              <TextInput
                accessibilityLabel="Buscar produtos"
                onChangeText={setSearch}
                placeholder="O que você está procurando?"
                placeholderTextColor={colors.mutedForeground}
                returnKeyType="search"
                style={[styles.searchInput, { color: colors.foreground }]}
                testID="product-search"
                value={search}
              />
              {search ? (
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Limpar busca"
                  onPress={() => setSearch('')}
                  testID="clear-search"
                >
                  <Feather name="x-circle" size={18} color={colors.mutedForeground} />
                </Pressable>
              ) : null}
            </View>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.categoryRow}
            >
              {categoryFilters.map((category) => {
                const selected = selectedCategory === category;
                return (
                  <Pressable
                    accessibilityRole="button"
                    accessibilityState={{ selected }}
                    key={category}
                    onPress={() => setSelectedCategory(category)}
                    style={[
                      styles.categoryChip,
                      {
                        backgroundColor: selected
                          ? colors.accent
                          : colors.secondary,
                        borderColor: selected ? colors.border : 'transparent',
                      },
                    ]}
                    testID={`category-${category}`}
                  >
                    <Text
                      style={[
                        styles.categoryLabel,
                        {
                          color: selected
                            ? colors.accentForeground
                            : colors.secondaryForeground,
                        },
                      ]}
                    >
                      {category}
                    </Text>
                  </Pressable>
                );
              })}
            </ScrollView>
            <View style={styles.sectionHeading}>
              <View>
                <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
                  Achados para você
                </Text>
                <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>
                  Peças únicas, perto de você
                </Text>
              </View>
              <View style={[styles.countBadge, { backgroundColor: colors.accent }]}>
                <Feather name="star" size={17} color={colors.accentForeground} />
              </View>
            </View>
            {storageError ? (
              <Text style={[styles.storageNotice, { color: colors.destructive }]}>
                {storageError}
              </Text>
            ) : null}
            {!isReady ? (
              <View style={styles.loading}>
                <ActivityIndicator color={colors.tint} />
              </View>
            ) : null}
          </View>
        }
          ListEmptyComponent={
          isReady ? (
            <View style={styles.emptyState}>
              <Feather name="search" size={30} color={colors.mutedForeground} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
                Nenhum achado por aqui
              </Text>
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                Tente outra busca ou escolha uma categoria diferente.
              </Text>
              </View>
            ) : undefined
        }
        renderItem={({ item }) => (
          <View style={styles.cardCell}>
            <ListingCard
              listing={item}
              isFavorite={favorites.includes(item.id)}
              onFavorite={() => handleFavorite(item.id)}
              onPress={() => openListing(item.id)}
            />
          </View>
        )}
        showsVerticalScrollIndicator={false}
        style={styles.list}
      />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },
  list: {
    flex: 1,
  },
  listContent: {
    flexGrow: 1,
    paddingHorizontal: 20,
  },
  emptyListContent: {
    flexGrow: 1,
  },
  brandLine: {
    minHeight: 32,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  eyebrow: {
    fontFamily: 'Inter_700Bold',
    fontSize: 12,
    letterSpacing: 1.8,
  },
  headerAction: {
    width: 44,
    height: 44,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  hero: {
    maxWidth: 320,
    fontFamily: 'Inter_700Bold',
    fontSize: 30,
    lineHeight: 36,
    marginTop: 7,
    marginBottom: 22,
  },
  searchField: {
    minHeight: 56,
    borderWidth: 1,
    borderRadius: 18,
    paddingHorizontal: 15,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 11,
  },
  searchInput: {
    flex: 1,
    minHeight: 52,
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
  },
  categoryRow: {
    gap: 9,
    paddingTop: 17,
    paddingBottom: 22,
  },
  categoryChip: {
    minHeight: 40,
    borderWidth: 1,
    borderRadius: 99,
    paddingHorizontal: 17,
    alignItems: 'center',
    justifyContent: 'center',
  },
  categoryLabel: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 13,
  },
  sectionHeading: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  sectionTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 21,
  },
  sectionSubtitle: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    marginTop: 3,
  },
  countBadge: {
    width: 40,
    height: 40,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  column: {
    gap: 12,
    justifyContent: 'space-between',
  },
  cardCell: {
    width: '48%',
  },
  storageNotice: {
    fontFamily: 'Inter_500Medium',
    fontSize: 12,
    marginBottom: 12,
  },
  loading: {
    minHeight: 100,
    justifyContent: 'center',
  },
  emptyState: {
    flex: 1,
    minHeight: 190,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 28,
    gap: 10,
  },
  emptyTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 17,
    textAlign: 'center',
  },
  emptyText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    textAlign: 'center',
    lineHeight: 19,
  },
});
