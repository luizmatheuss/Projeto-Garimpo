import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useMemo } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ListingCard } from '@/components/ListingCard';
import { useMarketplace } from '@/contexts/MarketplaceContext';
import { useColors } from '@/hooks/useColors';

export default function FavoritesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { listings, favorites, isReady, storageError, toggleFavorite } =
    useMarketplace();
  const favoriteListings = useMemo(
    () => listings.filter((listing) => favorites.includes(listing.id)),
    [listings, favorites],
  );
  const topInset =
    Platform.OS === 'web' ? Math.max(insets.top, 67) + 10 : insets.top + 18;

  const openListing = (id: string) => {
    router.push({ pathname: '/listing/[id]', params: { id } });
  };

  const handleFavorite = (id: string) => {
    void toggleFavorite(id).catch(() =>
      Alert.alert(
        'Não foi possível atualizar',
        'Tente remover este item dos favoritos novamente.',
      ),
    );
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <FlatList
        data={isReady ? favoriteListings : []}
        numColumns={2}
        keyExtractor={(item) => item.id}
        contentContainerStyle={[
          styles.content,
          { paddingTop: topInset, paddingBottom: Platform.OS === 'web' ? 34 : 24 },
        ]}
        columnWrapperStyle={styles.column}
        ListHeaderComponent={
          <View style={styles.header}>
            <View>
              <Text style={[styles.eyebrow, { color: colors.tint }]}>SUA LISTA</Text>
              <Text style={[styles.title, { color: colors.foreground }]}>
                Favoritos
              </Text>
            </View>
            <View style={[styles.headerIcon, { backgroundColor: colors.accent }]}>
              <Feather name="heart" size={22} color={colors.accentForeground} />
            </View>
            {storageError ? (
              <Text style={[styles.storageNotice, { color: colors.destructive }]}>
                {storageError}
              </Text>
            ) : null}
          </View>
        }
        ListEmptyComponent={
          isReady ? (
            <View style={styles.emptyState}>
              <View style={[styles.emptyIcon, { backgroundColor: colors.accent }]}>
                <Feather name="heart" size={25} color={colors.accentForeground} />
              </View>
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
                Seus achados ficam aqui
              </Text>
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                Toque no coração de um anúncio para guardar e voltar depois.
              </Text>
              <Pressable
                accessibilityRole="button"
                onPress={() => router.navigate('/(tabs)')}
                style={({ pressed }) => [
                  styles.exploreButton,
                  { backgroundColor: colors.primary },
                  pressed && styles.pressed,
                ]}
                testID="explore-from-favorites"
              >
                <Text style={[styles.buttonText, { color: colors.primaryForeground }]}>
                  Explorar anúncios
                </Text>
                <Feather name="arrow-right" size={17} color={colors.primaryForeground} />
              </Pressable>
            </View>
          ) : (
            <View style={styles.loading}>
              <ActivityIndicator color={colors.tint} />
            </View>
          )
        }
        renderItem={({ item }) => (
          <View style={styles.cardCell}>
            <ListingCard
              listing={item}
              isFavorite
              onFavorite={() => handleFavorite(item.id)}
              onPress={() => openListing(item.id)}
            />
          </View>
        )}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },
  content: {
    flexGrow: 1,
    paddingHorizontal: 20,
  },
  header: {
    minHeight: 150,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    flexWrap: 'wrap',
    marginBottom: 14,
  },
  eyebrow: {
    fontFamily: 'Inter_700Bold',
    fontSize: 12,
    letterSpacing: 1.7,
    marginBottom: 6,
  },
  title: {
    fontFamily: 'Inter_700Bold',
    fontSize: 32,
  },
  headerIcon: {
    width: 52,
    height: 52,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  storageNotice: {
    width: '100%',
    fontFamily: 'Inter_500Medium',
    fontSize: 12,
    marginTop: 8,
  },
  column: {
    gap: 12,
    justifyContent: 'space-between',
  },
  cardCell: {
    width: '48%',
  },
  emptyState: {
    flex: 1,
    minHeight: 380,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  emptyIcon: {
    width: 58,
    height: 58,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 18,
  },
  emptyTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 19,
    textAlign: 'center',
    marginBottom: 7,
  },
  emptyText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    lineHeight: 21,
    textAlign: 'center',
    maxWidth: 290,
    marginBottom: 22,
  },
  exploreButton: {
    minHeight: 48,
    paddingHorizontal: 18,
    borderRadius: 15,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  buttonText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
  },
  pressed: {
    opacity: 0.84,
  },
  loading: {
    flex: 1,
    minHeight: 220,
    justifyContent: 'center',
  },
});
