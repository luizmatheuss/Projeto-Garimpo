import { Feather } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Image,
  Linking,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import {
  categories,
  type Category,
  type Condition,
  type Listing,
} from '@/data/listings';
import { useColors } from '@/hooks/useColors';
import { useMarketplace } from '@/contexts/MarketplaceContext';

const conditions: Condition[] = ['Novo', 'Seminovo', 'Usado'];

export default function SellScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { addListing } = useMarketplace();
  const [title, setTitle] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState<Category>('Moda');
  const [condition, setCondition] = useState<Condition>('Seminovo');
  const [city, setCity] = useState('');
  const [description, setDescription] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [photoUri, setPhotoUri] = useState<string | null>(null);
  const [isPublishing, setIsPublishing] = useState(false);
  const topInset =
    Platform.OS === 'web' ? Math.max(insets.top, 67) + 8 : insets.top + 12;

  const choosePhoto = async () => {
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        const settingsButton =
          Platform.OS !== 'web' && !permission.canAskAgain
            ? [
                {
                  text: 'Abrir configurações',
                  onPress: () => void Linking.openSettings(),
                },
              ]
            : [];
        Alert.alert(
          'Acesso às fotos',
          'Permita o acesso às fotos para adicionar uma imagem ao anúncio.',
          [...settingsButton, { text: 'Entendi', style: 'cancel' as const }],
        );
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });
      if (!result.canceled && result.assets[0]) {
        setPhotoUri(result.assets[0].uri);
      }
    } catch {
      Alert.alert(
        'Não foi possível abrir as fotos',
        'Tente novamente ou publique o anúncio sem imagem.',
      );
    }
  };

  const publishListing = async () => {
    const parsedPrice = Number(
      price.trim().replace(/\./g, '').replace(',', '.').replace(/[^\d.]/g, ''),
    );
    if (!title.trim() || !price.trim() || !city.trim() || !description.trim() || !whatsapp.trim()) {
      Alert.alert(
        'Faltam informações',
        'Preencha nome, preço, cidade, descrição e WhatsApp para publicar.',
      );
      return;
    }
    if (!Number.isFinite(parsedPrice) || parsedPrice <= 0) {
      Alert.alert('Preço inválido', 'Informe um preço maior que zero.');
      return;
    }
    const phoneDigits = whatsapp.replace(/\D/g, '');
    if (phoneDigits.length < 10 || phoneDigits.length > 13) {
      Alert.alert(
        'WhatsApp inválido',
        'Informe um telefone com DDD para que as pessoas possam falar com você.',
      );
      return;
    }

    const listing: Listing = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
      title: title.trim(),
      price: parsedPrice,
      category,
      condition,
      city: city.trim(),
      description: description.trim(),
      whatsapp: phoneDigits,
      ...(photoUri ? { photoUri } : {}),
      createdAt: new Date().toISOString(),
    };

    setIsPublishing(true);
    try {
      await addListing(listing);
      setTitle('');
      setPrice('');
      setCategory('Moda');
      setCondition('Seminovo');
      setCity('');
      setDescription('');
      setWhatsapp('');
      setPhotoUri(null);
      router.push({ pathname: '/listing/[id]', params: { id: listing.id } });
    } catch {
      Alert.alert(
        'Não foi possível publicar',
        'Seu anúncio não foi salvo. Verifique o armazenamento do aparelho e tente novamente.',
      );
    } finally {
      setIsPublishing(false);
    }
  };

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.screen, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: topInset,
          paddingBottom: Platform.OS === 'web' ? 34 : insets.bottom + 30,
        },
      ]}
      bottomOffset={72}
      keyboardShouldPersistTaps="handled"
      showsVerticalScrollIndicator={false}
    >
      <Text style={[styles.eyebrow, { color: colors.tint }]}>NOVO ANÚNCIO</Text>
      <Text style={[styles.heading, { color: colors.foreground }]}>
        Dê uma nova vida ao que você não usa.
      </Text>
      <Text style={[styles.intro, { color: colors.mutedForeground }]}>
        Conte o que está vendendo. É rápido e gratuito.
      </Text>

      <Pressable
        accessibilityRole="button"
        accessibilityLabel={photoUri ? 'Trocar foto do anúncio' : 'Adicionar foto'}
        onPress={() => void choosePhoto()}
        style={({ pressed }) => [
          styles.photoPicker,
          { backgroundColor: colors.secondary },
          pressed && styles.pressed,
        ]}
        testID="pick-listing-photo"
      >
        {photoUri ? (
          <Image source={{ uri: photoUri }} style={styles.photoPreview} />
        ) : (
          <View style={[styles.photoIcon, { backgroundColor: colors.accent }]}>
            <Feather name="camera" size={24} color={colors.accentForeground} />
          </View>
        )}
        <View style={styles.photoText}>
          <Text style={[styles.photoTitle, { color: colors.secondaryForeground }]}>
            {photoUri ? 'Foto adicionada' : 'Adicionar foto'}
          </Text>
          <Text style={[styles.photoSubtitle, { color: colors.mutedForeground }]}>
            Uma boa imagem ajuda a vender
          </Text>
        </View>
        <Feather
          name={photoUri ? 'check' : 'plus'}
          size={22}
          color={colors.tint}
        />
      </Pressable>

      <FieldLabel label="Nome do produto" color={colors.foreground} />
      <TextInput
        accessibilityLabel="Nome do produto"
        autoCapitalize="sentences"
        maxLength={60}
        onChangeText={setTitle}
        placeholder="Ex.: Jaqueta jeans vintage"
        placeholderTextColor={colors.mutedForeground}
        returnKeyType="next"
        style={[
          styles.input,
          { backgroundColor: colors.input, borderColor: colors.border, color: colors.foreground },
        ]}
        testID="listing-title"
        value={title}
      />

      <FieldLabel label="Preço" color={colors.foreground} />
      <View
        style={[
          styles.priceInputWrap,
          { backgroundColor: colors.input, borderColor: colors.border },
        ]}
      >
        <Text style={[styles.currency, { color: colors.mutedForeground }]}>R$</Text>
        <TextInput
          accessibilityLabel="Preço em reais"
          keyboardType="decimal-pad"
          maxLength={14}
          onChangeText={setPrice}
          placeholder="0,00"
          placeholderTextColor={colors.mutedForeground}
          returnKeyType="next"
          style={[styles.priceInput, { color: colors.foreground }]}
          testID="listing-price"
          value={price}
        />
      </View>

      <FieldLabel label="Categoria" color={colors.foreground} />
      <View style={styles.chipRow}>
        {categories.map((option) => {
          const selected = category === option;
          return (
            <ChoiceChip
              key={option}
              label={option}
              selected={selected}
              onPress={() => setCategory(option)}
              testID={`sell-category-${option}`}
            />
          );
        })}
      </View>

      <FieldLabel label="Estado" color={colors.foreground} />
      <View style={styles.chipRow}>
        {conditions.map((option) => (
          <ChoiceChip
            key={option}
            label={option}
            selected={condition === option}
            onPress={() => setCondition(option)}
            testID={`sell-condition-${option}`}
          />
        ))}
      </View>

      <FieldLabel label="Cidade" color={colors.foreground} />
      <TextInput
        accessibilityLabel="Cidade"
        autoCapitalize="words"
        maxLength={60}
        onChangeText={setCity}
        placeholder="Ex.: São Paulo, SP"
        placeholderTextColor={colors.mutedForeground}
        returnKeyType="next"
        style={[
          styles.input,
          { backgroundColor: colors.input, borderColor: colors.border, color: colors.foreground },
        ]}
        testID="listing-city"
        value={city}
      />

      <FieldLabel label="Descrição" color={colors.foreground} />
      <TextInput
        accessibilityLabel="Descrição do produto"
        autoCapitalize="sentences"
        maxLength={500}
        multiline
        onChangeText={setDescription}
        placeholder="Conte detalhes importantes para quem comprar."
        placeholderTextColor={colors.mutedForeground}
        style={[
          styles.input,
          styles.descriptionInput,
          { backgroundColor: colors.input, borderColor: colors.border, color: colors.foreground },
        ]}
        testID="listing-description"
        textAlignVertical="top"
        value={description}
      />

      <FieldLabel label="WhatsApp para contato" color={colors.foreground} />
      <TextInput
        accessibilityLabel="WhatsApp para contato"
        keyboardType="phone-pad"
        maxLength={20}
        onChangeText={setWhatsapp}
        placeholder="DDD + número"
        placeholderTextColor={colors.mutedForeground}
        returnKeyType="done"
        style={[
          styles.input,
          { backgroundColor: colors.input, borderColor: colors.border, color: colors.foreground },
        ]}
        testID="listing-whatsapp"
        value={whatsapp}
      />
      <Text style={[styles.helper, { color: colors.mutedForeground }]}>
        Seu número ficará visível no anúncio para que interessados possam falar com você.
      </Text>

      <Pressable
        accessibilityRole="button"
        disabled={isPublishing}
        onPress={() => void publishListing()}
        style={({ pressed }) => [
          styles.publishButton,
          { backgroundColor: colors.primary },
          pressed && !isPublishing && styles.pressed,
          isPublishing && styles.disabled,
        ]}
        testID="publish-listing"
      >
        {isPublishing ? (
          <ActivityIndicator color={colors.primaryForeground} />
        ) : (
          <>
            <Text style={[styles.publishText, { color: colors.primaryForeground }]}>
              Publicar anúncio
            </Text>
            <Feather name="arrow-right" size={20} color={colors.primaryForeground} />
          </>
        )}
      </Pressable>
    </KeyboardAwareScrollViewCompat>
  );
}

function FieldLabel({ label, color }: { label: string; color: string }) {
  return <Text style={[styles.fieldLabel, { color }]}>{label}</Text>;
}

function ChoiceChip({
  label,
  selected,
  onPress,
  testID,
}: {
  label: string;
  selected: boolean;
  onPress: () => void;
  testID: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected }}
      onPress={onPress}
      style={[
        styles.choiceChip,
        {
          backgroundColor: selected ? colors.accent : colors.secondary,
          borderColor: selected ? colors.border : 'transparent',
        },
      ]}
      testID={testID}
    >
      <Text
        style={[
          styles.choiceText,
          {
            color: selected
              ? colors.accentForeground
              : colors.secondaryForeground,
          },
        ]}
      >
        {label}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 20,
  },
  eyebrow: {
    fontFamily: 'Inter_700Bold',
    fontSize: 12,
    letterSpacing: 1.8,
    marginBottom: 9,
  },
  heading: {
    maxWidth: 380,
    fontFamily: 'Inter_700Bold',
    fontSize: 30,
    lineHeight: 37,
  },
  intro: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    lineHeight: 21,
    marginTop: 8,
    marginBottom: 24,
  },
  photoPicker: {
    minHeight: 96,
    borderRadius: 22,
    paddingHorizontal: 13,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 23,
  },
  photoIcon: {
    width: 56,
    height: 56,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
  },
  photoPreview: {
    width: 62,
    height: 62,
    borderRadius: 16,
  },
  photoText: {
    flex: 1,
    gap: 4,
  },
  photoTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
  },
  photoSubtitle: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
  },
  fieldLabel: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    marginBottom: 9,
    marginTop: 1,
  },
  input: {
    minHeight: 54,
    borderWidth: 1,
    borderRadius: 16,
    paddingHorizontal: 15,
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    marginBottom: 18,
  },
  priceInputWrap: {
    minHeight: 54,
    borderWidth: 1,
    borderRadius: 16,
    paddingHorizontal: 15,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 18,
  },
  currency: {
    fontFamily: 'Inter_500Medium',
    fontSize: 14,
    marginRight: 8,
  },
  priceInput: {
    flex: 1,
    minHeight: 52,
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
  },
  chipRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 19,
  },
  choiceChip: {
    minHeight: 40,
    paddingHorizontal: 14,
    borderWidth: 1,
    borderRadius: 99,
    alignItems: 'center',
    justifyContent: 'center',
  },
  choiceText: {
    fontFamily: 'Inter_500Medium',
    fontSize: 12,
  },
  descriptionInput: {
    minHeight: 110,
    paddingTop: 15,
    lineHeight: 20,
  },
  helper: {
    fontFamily: 'Inter_400Regular',
    fontSize: 11,
    lineHeight: 17,
    marginTop: -8,
    marginBottom: 21,
  },
  publishButton: {
    minHeight: 56,
    borderRadius: 17,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 18,
  },
  publishText: {
    fontFamily: 'Inter_700Bold',
    fontSize: 15,
  },
  pressed: {
    opacity: 0.84,
  },
  disabled: {
    opacity: 0.65,
  },
});
