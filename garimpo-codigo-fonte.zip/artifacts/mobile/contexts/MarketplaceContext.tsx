import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { sampleListings, type Listing } from '@/data/listings';

const STORAGE_KEY = 'garimpo-marketplace-v1';

interface StoredMarketplace {
  listings: Listing[];
  favorites: string[];
}

interface MarketplaceContextValue extends StoredMarketplace {
  isReady: boolean;
  storageError: string | null;
  addListing: (listing: Listing) => Promise<void>;
  toggleFavorite: (listingId: string) => Promise<void>;
}

const MarketplaceContext = createContext<MarketplaceContextValue | null>(null);

export function MarketplaceProvider({ children }: { children: ReactNode }) {
  const [listings, setListings] = useState<Listing[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [isReady, setIsReady] = useState(false);
  const [storageError, setStorageError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;

    const loadMarketplace = async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (!active) return;

        if (!raw) {
          const initialData: StoredMarketplace = {
            listings: sampleListings,
            favorites: [],
          };
          await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(initialData));
          if (!active) return;
          setListings(initialData.listings);
          setFavorites(initialData.favorites);
          return;
        }

        const parsed: unknown = JSON.parse(raw);
        if (
          typeof parsed !== 'object' ||
          parsed === null ||
          !Array.isArray((parsed as StoredMarketplace).listings) ||
          !Array.isArray((parsed as StoredMarketplace).favorites)
        ) {
          throw new Error('Dados salvos inválidos');
        }

        setListings((parsed as StoredMarketplace).listings);
        setFavorites((parsed as StoredMarketplace).favorites);
      } catch {
        if (active) {
          setListings(sampleListings);
          setFavorites([]);
          setStorageError(
            'Não foi possível carregar seus dados salvos neste aparelho.',
          );
        }
      } finally {
        if (active) setIsReady(true);
      }
    };

    void loadMarketplace();
    return () => {
      active = false;
    };
  }, []);

  const addListing = useCallback(
    async (listing: Listing) => {
      const nextListings = [listing, ...listings];
      try {
        await AsyncStorage.setItem(
          STORAGE_KEY,
          JSON.stringify({ listings: nextListings, favorites }),
        );
        setListings(nextListings);
        setStorageError(null);
      } catch (error) {
        setStorageError('Não foi possível salvar o anúncio neste aparelho.');
        throw error;
      }
    },
    [favorites, listings],
  );

  const toggleFavorite = useCallback(
    async (listingId: string) => {
      const nextFavorites = favorites.includes(listingId)
        ? favorites.filter((id) => id !== listingId)
        : [...favorites, listingId];
      try {
        await AsyncStorage.setItem(
          STORAGE_KEY,
          JSON.stringify({ listings, favorites: nextFavorites }),
        );
        setFavorites(nextFavorites);
        setStorageError(null);
      } catch (error) {
        setStorageError('Não foi possível salvar seus favoritos neste aparelho.');
        throw error;
      }
    },
    [favorites, listings],
  );

  const value = useMemo(
    () => ({
      listings,
      favorites,
      isReady,
      storageError,
      addListing,
      toggleFavorite,
    }),
    [listings, favorites, isReady, storageError, addListing, toggleFavorite],
  );

  return (
    <MarketplaceContext.Provider value={value}>
      {children}
    </MarketplaceContext.Provider>
  );
}

export function useMarketplace() {
  const context = useContext(MarketplaceContext);
  if (!context) {
    throw new Error('useMarketplace deve ser usado dentro de MarketplaceProvider');
  }
  return context;
}
