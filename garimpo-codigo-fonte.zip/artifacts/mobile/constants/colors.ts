/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const palette = {
  // Garimpo follows the warm, dark palette from the supplied mobile screens.
  text: '#e9e9df',
  tint: '#e87f68',
  background: '#211d14',
  foreground: '#e9e9df',
  card: '#2d2a22',
  cardForeground: '#e9e9df',
  primary: '#a72a12',
  primaryForeground: '#fff6ef',
  secondary: '#4b4941',
  secondaryForeground: '#f1f0e9',
  muted: '#353127',
  mutedForeground: '#b9b4a9',
  accent: '#10352b',
  accentForeground: '#a8e4cf',
  destructive: '#e9858b',
  destructiveForeground: '#211d14',
  border: '#5d574a',
  input: '#343129',
};

const colors = {
  light: palette,
  dark: palette,
  radius: 16,
};

export default colors;
