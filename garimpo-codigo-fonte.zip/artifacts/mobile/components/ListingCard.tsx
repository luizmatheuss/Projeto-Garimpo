import { Feather } from '@expo/vector-icons';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { formatPrice, getListingImageSource, type Listing } from '@/data/listings';
import { useColors } from '@/hooks/useColors';

interface ListingCardProps {
  listing: Listing;
  isFavorite: boolean;
  onPress: () => void;
  onFavorite: () => void;
}

export function ListingCard({
  listing,
  isFavorite,
  onPress,
  onFavorite,
}: ListingCardProps) {
  const colors = useColors();
  const imageSource = getListingImageSource(listing);

  return (
    <View
      style={[
        styles.card,
        { backgroundColor: colors.card, borderColor: colors.border },
      ]}
    >
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={`Ver ${listing.title}`}
        onPress={onPress}
        style={({ pressed }) => [styles.body, pressed && styles.pressed]}
        testID={`listing-${listing.id}`}
      >
        <View style={styles.imageFrame}>
          {imageSource ? (
            <Image
              source={imageSource}
              style={styles.image}
              resizeMode="cover"
            />
          ) : (
            <View
              style={[
                styles.imagePlaceholder,
                { backgroundColor: colors.muted },
              ]}
            >
              <Feather name="image" size={28} color={colors.mutedForeground} />
            </View>
          )}
          <View
            style={[
              styles.categoryTag,
              { backgroundColor: colors.background },
            ]}
          >
            <Text style={[styles.categoryText, { color: colors.foreground }]}>
              {listing.category}
            </Text>
          </View>
          {listing.isDemo ? (
            <View
              style={[
                styles.demoTag,
                { backgroundColor: colors.accent },
              ]}
            >
              <Text
                style={[
                  styles.demoText,
                  { color: colors.accentForeground },
                ]}
              >
                Exemplo
              </Text>
            </View>
          ) : null}
        </View>
        <View style={styles.details}>
          <Text
            numberOfLines={1}
            style={[styles.title, { color: colors.cardForeground }]}
          >
            {listing.title}
          </Text>
          <Text style={[styles.price, { color: colors.foreground }]}>
            {formatPrice(listing.price)}
          </Text>
          <Text
            numberOfLines={1}
            style={[styles.city, { color: colors.mutedForeground }]}
          >
            {listing.city}
          </Text>
        </View>
      </Pressable>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={
          isFavorite ? 'Remover dos favoritos' : 'Adicionar aos favoritos'
        }
        onPress={onFavorite}
        style={[
          styles.favoriteButton,
          { backgroundColor: colors.background },
        ]}
        testID={`favorite-${listing.id}`}
      >
        <Feather
          name="heart"
          size={17}
          color={isFavorite ? colors.tint : colors.foreground}
          fill={isFavorite ? colors.tint : 'transparent'}
        />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    minWidth: 0,
    overflow: 'hidden',
    borderWidth: 1,
    borderRadius: 18,
    marginBottom: 12,
  },
  body: {
    flex: 1,
  },
  pressed: {
    opacity: 0.84,
  },
  imageFrame: {
    height: 158,
    position: 'relative',
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  imagePlaceholder: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  categoryTag: {
    position: 'absolute',
    left: 9,
    bottom: 9,
    borderRadius: 99,
    paddingHorizontal: 10,
    paddingVertical: 5,
    opacity: 0.94,
  },
  categoryText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 10,
  },
  demoTag: {
    position: 'absolute',
    top: 9,
    left: 9,
    borderRadius: 99,
    paddingHorizontal: 9,
    paddingVertical: 5,
  },
  demoText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 9,
  },
  details: {
    paddingHorizontal: 11,
    paddingTop: 10,
    paddingBottom: 12,
    gap: 4,
  },
  title: {
    fontFamily: 'Inter_500Medium',
    fontSize: 12,
  },
  price: {
    fontFamily: 'Inter_700Bold',
    fontSize: 15,
  },
  city: {
    fontFamily: 'Inter_400Regular',
    fontSize: 10,
  },
  favoriteButton: {
    position: 'absolute',
    top: 9,
    right: 9,
    width: 34,
    height: 34,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 17,
  },
});
